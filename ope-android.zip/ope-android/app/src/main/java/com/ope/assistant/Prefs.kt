package com.ope.assistant

import android.content.Context
import java.io.File

object Prefs {
    const val GEMINI_KEY = "gemini_key"
    const val GEMINI_MODEL = "gemini_model"
    const val PICO_KEY = "pico_key"

    private fun sp(c: Context) = c.getSharedPreferences("ope", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): String = sp(c).getString(k, "") ?: ""
    fun set(c: Context, k: String, v: String) { sp(c).edit().putString(k, v.trim()).apply() }
    fun ppnFile(c: Context) = File(c.filesDir, "hey_ope.ppn")
}
