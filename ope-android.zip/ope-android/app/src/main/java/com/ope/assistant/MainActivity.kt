package com.ope.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var geminiKey: EditText
    private lateinit var geminiModel: EditText
    private lateinit var picoKey: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 80)
        }
        fun text(s: String, size: Float = 14f) = TextView(this).also {
            it.text = s
            it.textSize = size
            root.addView(it)
        }
        fun btn(s: String, f: () -> Unit) = Button(this).also {
            it.text = s
            it.setOnClickListener { f() }
            root.addView(it)
        }
        fun field(hint: String, value: String, secret: Boolean) = EditText(this).also {
            it.hint = hint
            it.setText(value)
            it.setSingleLine()
            if (secret) it.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            root.addView(it)
        }

        text("Ope", 28f)
        status = text("")

        text("\n1. Permissions", 18f)
        btn("Allow microphone, notifications, contacts") {
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.READ_CONTACTS
                ), 1
            )
        }
        btn("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Don't kill Ope in the background") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }

        text("\n2. Keys (optional)", 18f)
        text("Gemini API key (free at aistudio.google.com): lets Ope understand anything")
        geminiKey = field("AIza...", Prefs.get(this, Prefs.GEMINI_KEY), true)
        text("Gemini model (leave empty for the default)")
        geminiModel = field("gemini-2.5-flash-lite", Prefs.get(this, Prefs.GEMINI_MODEL), false)
        text("Picovoice AccessKey + your hey-ope .ppn file: no beeps, tiny battery use")
        picoKey = field("Picovoice AccessKey", Prefs.get(this, Prefs.PICO_KEY), true)
        btn("Pick wake word file (.ppn)") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }, 7
            )
        }
        btn("Save keys") {
            Prefs.set(this, Prefs.GEMINI_KEY, geminiKey.text.toString())
            Prefs.set(this, Prefs.GEMINI_MODEL, geminiModel.text.toString())
            Prefs.set(this, Prefs.PICO_KEY, picoKey.text.toString())
            Toast.makeText(this, "Saved. Stop and start listening to apply.", Toast.LENGTH_SHORT).show()
            refresh()
        }

        text("\n3. Run", 18f)
        btn("Start \"hey ope\" listening") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Allow the microphone first", Toast.LENGTH_SHORT).show()
            } else {
                ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))
            }
        }
        btn("Stop listening") { stopService(Intent(this, WakeService::class.java)) }
        btn("Set Ope as default assistant") { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }

        text("\n4. Test without talking", 18f)
        val testBox = field("e.g. open codm, or set a timer for 5 minutes", "", false)
        val out = text("")
        btn("Run test") {
            val q = testBox.text.toString()
            if (q.isNotBlank()) {
                out.text = "Thinking..."
                Brain.think(this, q) { r ->
                    out.text = r
                    Speaker.say(this, r)
                }
            }
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ai = Prefs.get(this, Prefs.GEMINI_KEY).isNotEmpty()
        val pico = Prefs.get(this, Prefs.PICO_KEY).isNotEmpty() && Prefs.ppnFile(this).exists()
        status.text = "AI: " + (if (ai) "on" else "off (basic commands only)") +
            "\nWake word: " + (if (pico) "Picovoice ready" else "basic mode (beeps, more battery)") +
            "\nOverlay card: " + (if (Settings.canDrawOverlays(this)) "allowed" else "not allowed")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { i ->
                    Prefs.ppnFile(this).outputStream().use { o -> i.copyTo(o) }
                }
                Toast.makeText(this, "Wake word file loaded", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't read that file", Toast.LENGTH_SHORT).show()
            }
            refresh()
        }
    }
}
