package com.ope.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout

// Lets you pick Ope as the phone's default assistant (power button / home gesture), like Gemini.
class OpeInteractionService : VoiceInteractionService()

class OpeSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = OpeSession(this)
}

class OpeSession(ctx: Context) : VoiceInteractionSession(ctx) {
    private var card: OpeCard? = null
    private var turn: VoiceTurn? = null

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    override fun onCreateContentView(): View {
        val c = OpeCard(context)
        card = c
        return FrameLayout(context).apply {
            setOnClickListener { hide() }
            addView(
                c.view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                ).apply { setMargins(dp(16), 0, dp(16), dp(24)) }
            )
        }
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val c = card ?: OpeCard(context).also { card = it }
        turn?.cancel()
        turn = VoiceTurn(context, c) { hide() }.also { it.start() }
    }

    override fun onHide() {
        turn?.cancel()
        turn = null
        super.onHide()
    }
}

// Stub: Android requires an assistant to declare a recognition service.
class OpeRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
