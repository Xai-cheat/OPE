package com.ope.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech

// One conversation turn: listen -> think -> do -> speak. Shared by the assistant gesture and "hey ope".
class VoiceTurn(
    private val ctx: Context,
    private val card: OpeCard,
    private val onDone: () -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var finished = false

    fun start() {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            fail("Allow the microphone in the Ope app")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            fail("No speech service on this phone")
            return
        }
        card.status("Listening...")
        rec = SpeechRecognizer.createSpeechRecognizer(ctx).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onPartialResults(partialResults: Bundle?) {
                    if (!finished) first(partialResults)?.let { card.heard(it) }
                }
                override fun onResults(results: Bundle?) {
                    if (finished) return
                    val t = first(results)
                    if (t.isNullOrBlank()) fail("I didn't catch that") else runText(t)
                }
                override fun onError(error: Int) {
                    if (finished) return
                    val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    fail(if (quiet) "I didn't catch that" else "Speech error $error")
                }
                override fun onRmsChanged(rmsdB: Float) { card.level(rmsdB) }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            )
        }
    }

    // Skip listening and act on text we already have (e.g. "hey ope open codm" said in one breath).
    fun runText(text: String) {
        if (finished) return
        card.heard(text)
        card.reply("Thinking...")
        Brain.think(ctx, text) { reply ->
            if (!finished) {
                card.reply(reply)
                Speaker.say(ctx, reply)
                finishLater(reply)
            }
        }
    }

    private fun first(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun fail(msg: String) {
        card.reply(msg)
        Speaker.say(ctx, msg)
        finishLater(msg)
    }

    private fun finishLater(text: String) {
        handler.postDelayed({ done() }, maxOf(2000L, text.length * 70L))
    }

    private fun done() {
        if (finished) return
        cancel()
        onDone()
    }

    fun cancel() {
        finished = true
        handler.removeCallbacksAndMessages(null)
        rec?.destroy()
        rec = null
    }
}

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    fun say(ctx: Context, text: String) {
        if (tts == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    pending?.let { speak(it) }
                    pending = null
                }
            }
        }
        if (ready) speak(text) else pending = text
    }

    private fun speak(t: String) {
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "ope")
    }
}
