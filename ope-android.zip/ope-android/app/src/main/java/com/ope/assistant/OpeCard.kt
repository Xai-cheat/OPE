package com.ope.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

// The floating Gemini-style card: glowing orb that pulses with your voice + what you said + Ope's reply.
class OpeCard(ctx: Context) {
    private val density = ctx.resources.displayMetrics.density
    private fun px(v: Int) = (v * density).toInt()

    private val orb = View(ctx).apply {
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF7C9CFF.toInt(), 0xFFB57CFF.toInt())
        ).apply { shape = GradientDrawable.OVAL }
    }
    private val title = TextView(ctx).apply {
        text = "Listening..."
        setTextColor(Color.WHITE)
        textSize = 18f
    }
    private val sub = TextView(ctx).apply {
        setTextColor(0xCCFFFFFF.toInt())
        textSize = 15f
        visibility = View.GONE
    }

    val view: View = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(px(20), px(18), px(20), px(18))
        background = GradientDrawable().apply {
            setColor(0xE61B1C2A.toInt())
            cornerRadius = px(28).toFloat()
            setStroke(px(1), 0x33FFFFFF)
        }
        addView(orb, LinearLayout.LayoutParams(px(44), px(44)).apply { marginEnd = px(16) })
        addView(
            LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(sub)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
    }

    fun status(s: String) { title.text = s }
    fun heard(s: String) { title.text = "\u201C$s\u201D" }
    fun reply(s: String) { sub.text = s; sub.visibility = View.VISIBLE }
    fun level(rms: Float) {
        val s = 1f + rms.coerceIn(0f, 10f) / 10f * 0.6f
        orb.scaleX = s
        orb.scaleY = s
    }
}

// Shows the card on top of other apps (used by the "hey ope" service). Needs "display over other apps".
class Overlay(private val ctx: Context, private val card: OpeCard) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var shown = false

    fun show(): Boolean {
        if (shown) return true
        if (!Settings.canDrawOverlays(ctx)) return false
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            horizontalMargin = 0.04f
            verticalMargin = 0.05f
        }
        return try {
            wm.addView(card.view, lp)
            shown = true
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hide() {
        if (!shown) return
        try { wm.removeView(card.view) } catch (e: Exception) { }
        shown = false
    }
}
