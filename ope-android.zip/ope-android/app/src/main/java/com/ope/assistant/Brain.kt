package com.ope.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

// Turns what you said into an action. With a Gemini API key it understands anything;
// without one (or offline / over the free limit) it falls back to simple "open / play / call / search" rules.
object Brain {
    private const val DEFAULT_MODEL = "gemini-2.5-flash-lite"
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun think(ctx: Context, text: String, done: (String) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            val key = Prefs.get(app, Prefs.GEMINI_KEY)
            var prefix = ""
            val action: JSONObject = if (key.isNotEmpty()) {
                try {
                    askGemini(app, key, text)
                } catch (e: Exception) {
                    prefix = when (e.message) {
                        "HTTP 429" -> "Gemini limit reached for now. "
                        "HTTP 400", "HTTP 403" -> "Check your Gemini key. "
                        else -> "AI is offline. "
                    }
                    ruleBased(text)
                }
            } else {
                ruleBased(text)
            }
            main.post { done(prefix + Actions.execute(app, action)) }
        }
    }

    private fun askGemini(ctx: Context, key: String, text: String): JSONObject {
        val model = Prefs.get(ctx, Prefs.GEMINI_MODEL).ifBlank { DEFAULT_MODEL }
        val apps = Actions.installedLabels(ctx).take(150).joinToString(", ")
        val now = SimpleDateFormat("EEEE HH:mm", Locale.getDefault()).format(Date())
        val system = """You are Ope, a voice assistant on an Android phone. Turn the user's request into ONE action.
Reply with ONLY a JSON object, no markdown. Actions:
{"action":"open_app","name":"<app name>"}
{"action":"play_music","query":"<song and artist>","app":"<optional: youtube or spotify>"}
{"action":"call","target":"<contact name or number>"}
{"action":"send_sms","target":"<contact name or number>","text":"<message>"}
{"action":"set_alarm","hour":<0-23>,"minute":<0-59>,"label":"<text>"}
{"action":"set_timer","seconds":<integer>,"label":"<text>"}
{"action":"web_search","query":"<query>"}
{"action":"navigate","place":"<place>"}
{"action":"flashlight","on":<true or false>}
{"action":"answer","text":"<short spoken answer, max 2 sentences>"}
Use "answer" for questions, chat, or anything not covered. The request comes from speech recognition, so fix obvious mishearings (codm means Call of Duty Mobile).
Current time: $now
Installed apps: $apps"""

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("maxOutputTokens", 1024)
                    .put("temperature", 0.2)
                    .put("responseMimeType", "application/json")
            )

        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 8000
        conn.readTimeout = 20000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        val resp = conn.inputStream.bufferedReader().use { it.readText() }
        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        val out = sb.toString()
        return JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    }

    private fun ruleBased(raw: String): JSONObject {
        val t = raw.lowercase().trim()
        fun a(action: String, k: String, v: Any) = JSONObject().put("action", action).put(k, v)
        return when {
            t.startsWith("open ") -> a("open_app", "name", t.removePrefix("open ").trim())
            t.startsWith("play ") -> a("play_music", "query", t.removePrefix("play ").trim())
            t.startsWith("call ") -> a("call", "target", t.removePrefix("call ").trim())
            t.startsWith("search ") -> a("web_search", "query", t.removePrefix("search ").trim())
            t.startsWith("navigate to ") -> a("navigate", "place", t.removePrefix("navigate to ").trim())
            t.contains("flashlight") || t.contains("torch") -> a("flashlight", "on", !t.contains("off"))
            else -> a("answer", "text", "Add a Gemini key in the Ope app so I can understand that. Without it I only know open, play, call, search and flashlight.")
        }
    }
}
