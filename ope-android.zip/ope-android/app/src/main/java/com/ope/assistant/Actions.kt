package com.ope.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import org.json.JSONObject

// Everything Ope can DO. Each action is a small JSON object, e.g. {"action":"open_app","name":"youtube"}
object Actions {
    private val codm = listOf("com.garena.game.codm", "com.activision.callofduty.shooter")
    private val aliases = mapOf(
        "codm" to codm,
        "cod" to codm,
        "cod mobile" to codm,
        "call of duty" to codm,
        "call of duty mobile" to codm,
        "youtube" to listOf("com.google.android.youtube"),
        "spotify" to listOf("com.spotify.music"),
    )

    fun execute(ctx: Context, a: JSONObject): String = try {
        when (a.optString("action")) {
            "open_app" -> openApp(ctx, a.optString("name"))
            "play_music" -> playMusic(ctx, a.optString("query"), a.optString("app"))
            "call" -> call(ctx, a.optString("target"))
            "send_sms" -> sms(ctx, a.optString("target"), a.optString("text"))
            "set_alarm" -> alarm(ctx, a.optInt("hour"), a.optInt("minute"), a.optString("label"))
            "set_timer" -> timer(ctx, a.optInt("seconds"), a.optString("label"))
            "web_search" -> webSearch(ctx, a.optString("query"))
            "navigate" -> navigate(ctx, a.optString("place"))
            "flashlight" -> flashlight(ctx, a.optBoolean("on", true))
            "answer" -> a.optString("text").ifBlank { "I have nothing to say." }
            else -> "I didn't understand that."
        }
    } catch (e: Exception) {
        "That failed: ${e.message}"
    }

    fun installedLabels(ctx: Context): List<String> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() }.distinct().sorted()
    }

    private fun launch(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    private fun openApp(ctx: Context, nameRaw: String): String {
        val name = nameRaw.lowercase().trim()
        if (name.isEmpty()) return "Which app?"
        val pm = ctx.packageManager
        val viaAlias = aliases[name]?.firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
        if (viaAlias != null) {
            return if (launch(ctx, viaAlias)) "Opening $nameRaw" else "Couldn't open $nameRaw"
        }
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val hit = apps.firstOrNull { it.first.lowercase() == name }
            ?: apps.firstOrNull { it.first.lowercase().startsWith(name) }
            ?: apps.firstOrNull { it.first.lowercase().contains(name) }
            ?: return "No app called $nameRaw"
        val intent = pm.getLaunchIntentForPackage(hit.second) ?: return "Can't open ${hit.first}"
        return if (launch(ctx, intent)) "Opening ${hit.first}" else "Couldn't open ${hit.first}"
    }

    private fun playMusic(ctx: Context, query: String, app: String): String {
        if (query.isBlank()) return "What should I play?"
        if (!app.lowercase().contains("youtube")) {
            val media = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(SearchManager.QUERY, query)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            if (launch(ctx, media)) return "Playing $query"
        }
        val url = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        return if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) "Searching YouTube for $query" else "Couldn't play $query"
    }

    private fun resolveNumber(ctx: Context, target: String): String? {
        if (target.count { it.isDigit() } >= 3) return target.filter { it.isDigit() || it == '+' }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        ctx.contentResolver.query(
            phone,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$target%"),
            null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private fun call(ctx: Context, target: String): String {
        val number = resolveNumber(ctx, target) ?: return "I couldn't find $target (allow contacts access)"
        return if (launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))) "Dialing $target" else "No dialer found"
    }

    private fun sms(ctx: Context, target: String, text: String): String {
        val number = resolveNumber(ctx, target) ?: return "I couldn't find $target (allow contacts access)"
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text)
        return if (launch(ctx, i)) "Message to $target ready, tap send" else "No messaging app found"
    }

    private fun alarm(ctx: Context, h: Int, m: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) "Alarm set for %d:%02d".format(h, m) else "No clock app found"
    }

    private fun timer(ctx: Context, seconds: Int, label: String): String {
        if (seconds <= 0) return "How long?"
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val mins = seconds / 60
        val secs = seconds % 60
        val human = when {
            mins == 0 -> "$secs seconds"
            secs == 0 -> "$mins minutes"
            else -> "$mins minutes $secs seconds"
        }
        return if (launch(ctx, i)) "Timer set for $human" else "No clock app found"
    }

    private fun webSearch(ctx: Context, query: String): String {
        if (query.isBlank()) return "Search for what?"
        if (launch(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query))) return "Searching $query"
        val url = "https://www.google.com/search?q=" + Uri.encode(query)
        return if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) "Searching $query" else "No browser found"
    }

    private fun navigate(ctx: Context, place: String): String {
        if (place.isBlank()) return "Where to?"
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place)))
        return if (launch(ctx, i)) "Navigating to $place" else "No maps app found"
    }

    private fun flashlight(ctx: Context, on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flashlight on this phone"
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on" else "Flashlight off"
    }
}
