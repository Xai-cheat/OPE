package com.ope.assistant

import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

// Always-on "hey ope".
// Best mode: Picovoice Porcupine (on-device, tiny battery use, no beeps) - needs a free key + your .ppn file.
// Basic mode: loops Android's speech recognizer (works with zero setup but beeps and uses more battery).
class WakeService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var porcupine: PorcupineManager? = null
    private var legacy: SpeechRecognizer? = null
    private var running = false
    private var busy = false
    private var turn: VoiceTurn? = null
    private var overlay: Overlay? = null
    private val mutedByUs = mutableListOf<Int>()
    private val wake = Regex("""hey[, ]+(?:ope|opie|opey|opay|hope|oh pay)\b[,. ]*(.*)""")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Allow the microphone first")
            stopSelf()
            return START_NOT_STICKY
        }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ope", "Ope", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ope")
            .setContentTitle("Ope is listening")
            .setContentText("Say \"hey ope\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            // Android refuses to restart a mic service from the background; open the app and tap Start.
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            startDetection()
        }
        return START_STICKY
    }

    private fun startDetection() {
        val key = Prefs.get(this, Prefs.PICO_KEY)
        val ppn = Prefs.ppnFile(this)
        if (key.isNotEmpty() && ppn.exists()) {
            try {
                porcupine = PorcupineManager.Builder()
                    .setAccessKey(key)
                    .setKeywordPath(ppn.absolutePath)
                    .setSensitivity(0.7f)
                    .build(applicationContext, PorcupineManagerCallback { _ -> handler.post { onWake(null) } })
                porcupine?.start()
                return
            } catch (e: Exception) {
                porcupine = null
                toast("Wake word engine failed (${e.message}). Using basic mode.")
            }
        }
        listenLegacy()
    }

    private fun onWake(inline: String?) {
        if (busy || !running) return
        busy = true
        pauseDetection()
        val card = OpeCard(this)
        val ov = Overlay(this, card)
        ov.show()
        overlay = ov
        val t = VoiceTurn(this, card) { endTurn() }
        turn = t
        card.view.setOnClickListener { endTurn() }
        if (inline.isNullOrBlank()) t.start() else t.runText(inline)
    }

    private fun endTurn() {
        turn?.cancel()
        turn = null
        overlay?.hide()
        overlay = null
        busy = false
        if (running) handler.postDelayed({ resumeDetection() }, 500)
    }

    private fun pauseDetection() {
        unmuteBeep()
        handler.removeCallbacksAndMessages(null)
        try { porcupine?.stop() } catch (e: Exception) { }
        legacy?.destroy()
        legacy = null
    }

    private fun resumeDetection() {
        if (!running || busy) return
        if (porcupine != null) {
            try { porcupine?.start() } catch (e: Exception) { toast("Wake word error: ${e.message}") }
        } else {
            listenLegacy()
        }
    }

    // ---- basic mode ----
    private fun listenLegacy() {
        if (!running || busy) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("No speech service on this phone")
            stopSelf()
            return
        }
        legacy?.destroy()
        legacy = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase()
                    val m = t?.let { wake.find(it) }
                    if (m != null) onWake(m.groupValues[1].trim()) else again(300)
                }
                override fun onError(error: Int) {
                    when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> again(1500)
                        else -> again(300)
                    }
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            muteBeep()
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            )
        }
    }

    private fun again(ms: Long) {
        if (running && !busy) handler.postDelayed({ listenLegacy() }, ms)
    }

    // Best effort: silence the recognizer's start beep for a moment. Never leaves the phone muted.
    private fun muteBeep() {
        val am = getSystemService(AudioManager::class.java)
        for (s in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try {
                if (!am.isStreamMute(s)) {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                    mutedByUs.add(s)
                }
            } catch (e: Exception) { }
        }
        handler.postDelayed({ unmuteBeep() }, 900)
    }

    private fun unmuteBeep() {
        val am = getSystemService(AudioManager::class.java)
        for (s in mutedByUs) {
            try { am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) { }
        }
        mutedByUs.clear()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        running = false
        unmuteBeep()
        handler.removeCallbacksAndMessages(null)
        turn?.cancel()
        overlay?.hide()
        try {
            porcupine?.stop()
            porcupine?.delete()
        } catch (e: Exception) { }
        legacy?.destroy()
        super.onDestroy()
    }
}
