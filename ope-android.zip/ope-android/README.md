# Ope
Build: put this zip + the build.yml workflow in a GitHub repo (see chat).
Optional setup in the app:
- Gemini API key (aistudio.google.com > Get API key, free tier) -> Ope understands anything.
- Picovoice AccessKey + custom "hey ope" .ppn (console.picovoice.ai > Porcupine, Android) -> no beeps, low battery.
Edit app/src/main/java/com/ope/assistant/Actions.kt to add your own shortcuts.
